<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
<br><br><br>
    <main>
        <div class="grid-container">
            <!-- Services Section -->
            <section class="services">
                <h1>Our Services</h1>
                <p>At Dental Clinic, we offer a wide range of healthcare services to meet your needs:</p>
                <ul class="service-list">
                    <li>General Checkups</li>
                    <li>Specialist Consultations</li>
                    <li>Laboratory Services</li>
                    <li>Pharmacy</li>
                    <li>Emergency Care</li>
                    <li>Vaccinations</li>
                </ul>
            </section>

            <!-- Why Choose Us Section -->
            <section class="why-choose-us">
                <h1>Why Choose Us?</h1>
                <p>We are committed to providing the best healthcare services with a patient-first approach.</p>
                <ul class="choose-list">
                    <li>Highly Qualified Doctors</li>
                    <li>State-of-the-Art Facilities</li>
                    <li>Personalized Care Plans</li>
                    <li>Affordable Pricing</li>
                    <li>24/7 Emergency Support</li>
                </ul>
            </section>

            <!-- Testimonials Section -->
            <section class="testimonials">
                <h1>What Our Patients Say</h1>
                <div class="testimonial">
                    <p>"The doctors and staff at Dental Clinic are amazing! They truly care about their patients."</p>
                    <h3>- Sarah A.</h3>
                </div>
                <div class="testimonial">
                    <p>"I had a great experience at Dental Clinic. The facilities are top-notch, and the staff is very professional."</p>
                    <h3>- John D.</h3>
                </div>
            </section>

            <!-- FAQs Section -->
            <section class="faqs">
                <h1>Frequently Asked Questions</h1>
                <div class="faq">
                    <h3>What are your operating hours?</h3>
                    <p>We are open from 24/7 throughout the year giving our patients high end services.</p>
                </div>
                <div class="faq">
                    <h3>Do you accept insurance?</h3>
                    <p>Yes, we accept most major insurance providers. Please contact us for more details.</p>
                </div>
            </section>
        </div>
    </main>
</body>
</html>