<?php include 'header.php'; ?>
<?php

$conn = new mysqli("localhost", "root", "", "kavs");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the logged-in doctor's email
$doctor_email = $_SESSION['user_email'];

// Fetch the doctor's ID
$stmt = $conn->prepare("SELECT id FROM doctors WHERE email = ?");
$stmt->bind_param("s", $doctor_email);
$stmt->execute();
$result = $stmt->get_result();
$doctor = $result->fetch_assoc();
$doctor_id = $doctor['id'];

// Fetch unique patients for the logged-in doctor
$stmt = $conn->prepare("SELECT DISTINCT patient_name, patient_email FROM appointments WHERE doctor_id = ?");
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patients - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="patients">
            <h1>Patients</h1>
            <p>Here is the list of your patients:</p>
            <table border="1">
                <tr>
                    <th>Patient Name</th>
                    <th>Patient Email</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['patient_name']); ?></td>
                        <td><?= htmlspecialchars($row['patient_email']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        </section>
    </main>
</body>
</html>