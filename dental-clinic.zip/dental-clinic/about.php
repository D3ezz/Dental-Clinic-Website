<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>

    <br><br><br><br><br><br>
    <main>
        <section class="about-intro">
            <h1>About Dental Clinic</h1>
            <p>At Dental Clinic, we are dedicated to providing world-class healthcare services with a patient-first approach. Learn more about who we are and what we stand for.</p>
        </section>

        <div class="our-container">
            <!-- Our Mission Section -->
            <section class="our-mission">
                <h1>Our Mission</h1>
                <p>To deliver exceptional healthcare services that improve the quality of life for our patients and their families.</p>
            </section>

            <!-- Our Vision Section -->
            <section class="our-vision">
                <h1>Our Vision</h1>
                <p>To be the leading healthcare provider in the region, known for innovation, compassion, and excellence in patient care.</p>
            </section>

            <!-- Our Team Section -->
            <section class="our-team">
                <h1>Our Team</h1>
                <p>Our team of highly qualified doctors, nurses, and support staff work tirelessly to ensure the best outcomes for our patients.</p>
            </section>

            <!-- Our History Section -->
            <section class="our-history">
                <h1>Our History</h1>
                <p>Founded in 2005, Dental Clinic has grown from a small practice to a state-of-the-art healthcare facility serving thousands of patients annually.</p>
            </section>
        </div>
    </main>
</body>
</html>