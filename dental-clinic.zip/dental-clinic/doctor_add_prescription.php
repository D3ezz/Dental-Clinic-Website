<?php include 'header.php'; ?>
<?php
$conn = new mysqli("localhost", "root", "", "kavs");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the logged-in doctor's email
$doctor_email = $_SESSION['user_email'];

// Fetch the doctor's ID
$stmt = $conn->prepare("SELECT id FROM doctors WHERE email = ?");
$stmt->bind_param("s", $doctor_email);
$stmt->execute();
$result = $stmt->get_result();
$doctor = $result->fetch_assoc();
$doctor_id = $doctor['id'];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_email = $_POST['patient_email'];
    $prescription_text = $_POST['prescription_text'];

    $stmt = $conn->prepare("INSERT INTO prescriptions (doctor_id, patient_email, prescription_text) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $doctor_id, $patient_email, $prescription_text);

    if ($stmt->execute()) {
        // Redirect to a success page
        header("Location: prescription_success.php");
        exit();
    } else {
        // Redirect to an error page or show an inline error
        header("Location: prescription_error.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Prescription - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="add-prescription">
            <h1>Add Prescription</h1>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="patient_email">Patient Email</label>
                    <input type="email" id="patient_email" name="patient_email" placeholder="Enter patient's email" required>
                </div>
                <div class="form-group">
                    <label for="prescription_text">Prescription</label>
                    <textarea id="prescription_text" name="prescription_text" placeholder="Enter prescription details" rows="5" required></textarea>
                </div>
                <button type="submit" class="btn-submit">Add Prescription</button>
            </form>
        </section>
    </main>
</body>
</html>