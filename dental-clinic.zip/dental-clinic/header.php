<?php
session_start(); // Ensure session is started

// Get the current page name to highlight the active tab
$current_page = basename($_SERVER['PHP_SELF']);
?>
<nav class="navbar">
    <ul class="nav-left">
        <?php if (isset($_SESSION['user_email']) && strpos($_SESSION['user_email'], '@dentalclinic.com') !== false): ?>
            <!-- Doctor's Navigation -->
            <li><a href="doctor_dashboard.php" class="<?= $current_page == 'doctor_dashboard.php' ? 'active' : '' ?>">Home</a></li>
            <li><a href="doctor_appointments.php" class="<?= $current_page == 'doctor_appointments.php' ? 'active' : '' ?>">Appointments</a></li>
            <li><a href="doctor_patients.php" class="<?= $current_page == 'doctor_patients.php' ? 'active' : '' ?>">Patients</a></li>
            <li><a href="doctor_add_prescription.php" class="<?= $current_page == 'doctor_add_prescription.php' ? 'active' : '' ?>">Add Prescription</a></li>
        <?php elseif (isset($_SESSION['user_email']) && strpos($_SESSION['user_email'], '@dentalclinic.com') === false): ?>
            <!-- Patient's Navigation -->
            <li><a href="index.php" class="<?= $current_page == 'index.php' ? 'active' : '' ?>">Home</a></li>
            <li><a href="appointment.php" class="<?= $current_page == 'appointment.php' ? 'active' : '' ?>">Appointment</a></li>
            <li><a href="services.php" class="<?= $current_page == 'services.php' ? 'active' : '' ?>">Services</a></li>
            <li><a href="about.php" class="<?= $current_page == 'about.php' ? 'active' : '' ?>">About Us</a></li>
            <li><a href="contact.php" class="<?= $current_page == 'contact.php' ? 'active' : '' ?>">Contact Us</a></li>
            <li><a href="patient_view_prescriptions.php" class="<?= $current_page == 'patient_view_prescriptions.php' ? 'active' : '' ?>">Prescriptions</a></li>
        <?php else: ?>
            <!-- Guest Navigation -->
            <li><a href="index.php" class="<?= $current_page == 'index.php' ? 'active' : '' ?>">Home</a></li>
            <li><a href="appointment.php" class="<?= $current_page == 'appointment.php' ? 'active' : '' ?>">Appointment</a></li>
            <li><a href="services.php" class="<?= $current_page == 'services.php' ? 'active' : '' ?>">Services</a></li>
            <li><a href="about.php" class="<?= $current_page == 'about.php' ? 'active' : '' ?>">About Us</a></li>
            <li><a href="contact.php" class="<?= $current_page == 'contact.php' ? 'active' : '' ?>">Contact Us</a></li>
        <?php endif; ?>
    </ul>
    <ul class="nav-right">
        <?php if (isset($_SESSION['user_name'])): ?>
            <li>
                <a href="profile.php" class="<?= $current_page == 'profile.php' ? 'active' : '' ?>">
                    <i class="bx bx-user"></i> <!-- Profile Icon -->
                    <?= htmlspecialchars($_SESSION['user_name']); ?>
                </a>
            </li>
        <?php else: ?>
            <li><a href="login.php" class="<?= $current_page == 'login.php' ? 'active' : '' ?>">Login</a></li>
            <li><a href="registration.php" class="<?= $current_page == 'registration.php' ? 'active' : '' ?>">Sign Up</a></li>
        <?php endif; ?>
    </ul>
</nav>