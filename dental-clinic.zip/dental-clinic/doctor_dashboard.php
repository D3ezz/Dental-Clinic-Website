<?php
include 'header.php';

// Ensure only doctors can access this page
if (!isset($_SESSION['user_email']) || strpos($_SESSION['user_email'], '@dentalclinic.com') === false) {
    header("Location: login.php");
    exit();
}

// Connect to the database
$conn = new mysqli("localhost", "root", "", "kavs");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the doctor's name
$doctor_email = $_SESSION['user_email'];
$doctor_query = "SELECT name FROM registration WHERE email='$doctor_email'";
$doctor_result = $conn->query($doctor_query);

// Get the doctor's name
$doctor_name = "Doctor";
if ($doctor_result && $doctor_result->num_rows > 0) {
    $doctor_data = $doctor_result->fetch_assoc();
    $doctor_name = htmlspecialchars($doctor_data['name']);
}

// Fetch the next appointment for the doctor
$appointment_query = "SELECT patient_name, appointment_date, appointment_time 
                      FROM appointments 
                      WHERE doctor_email='$doctor_email' 
                      AND CONCAT(appointment_date, ' ', appointment_time) > NOW() 
                      ORDER BY CONCAT(appointment_date, ' ', appointment_time) ASC 
                      LIMIT 1";
$appointment_result = $conn->query($appointment_query);

$next_appointment = null;
if ($appointment_result && $appointment_result->num_rows > 0) {
    $next_appointment = $appointment_result->fetch_assoc();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <script>
        // Countdown Timer
        function startCountdown(appointmentDateTime) {
            const countdownElement = document.getElementById('countdown');
            const targetDate = new Date(appointmentDateTime).getTime();

            function updateCountdown() {
                const now = new Date().getTime();
                const distance = targetDate - now;

                if (distance < 0) {
                    countdownElement.innerHTML = "Appointment is ongoing or has passed.";
                    clearInterval(interval);
                    return;
                }

                const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                countdownElement.innerHTML = `${hours}h ${minutes}m ${seconds}s`;
            }

            const interval = setInterval(updateCountdown, 1000);
            updateCountdown();
        }
    </script>
</head>
<body onload="<?= $next_appointment ? "startCountdown('" . $next_appointment['appointment_date'] . " " . $next_appointment['appointment_time'] . "')" : "" ?>">
    <main>
        <section class="quick-links">
            <br><br><br>
            <h1>Welcome, Dr. <?= $doctor_name; ?></h1>
            <p class="inspiring-quote">"The art of medicine consists of amusing the patient while nature cures the disease." – Voltaire</p>
            <br><br><br>
        </section>
    </main>
</body>
</html>