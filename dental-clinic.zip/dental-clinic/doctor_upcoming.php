<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upcoming Appointments - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="upcoming">
            <h1>Upcoming Appointments</h1>
            <p>Here are your upcoming appointments:</p>
            <ul>
                <li>John Doe - 10:00 AM, April 25</li>
                <li>Jane Smith - 11:30 AM, April 25</li>
                <li>Mark Johnson - 2:00 PM, April 25</li>
            </ul>
        </section>
    </main>
</body>
</html>