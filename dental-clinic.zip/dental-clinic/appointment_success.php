<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Successful - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="confirmation">
            <h1>Appointment Successfully Booked!</h1>
            <p>Thank you for booking your appointment with us. We look forward to seeing you!</p>
            <p><a href="appointment.php">Back to Appointments</a></p>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Dental Clinic. All rights reserved.</p>
    </footer>
</body>
</html>