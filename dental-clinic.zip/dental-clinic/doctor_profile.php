<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Profile - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="profile">
            <h1>Welcome, Dr. <?= htmlspecialchars($_SESSION['user_name']); ?></h1>
            <p>This is your profile page.</p>
            <a href="logout.php" class="btn-logout">Logout</a>
        </section>
    </main>
</body>
</html>