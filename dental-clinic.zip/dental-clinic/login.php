<?php
include 'header.php'; // Include the header

// Connect to the database
$conn = new mysqli("localhost", "root", "", "kavs");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize error flag
$login_error = false;

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Escape input to prevent SQL injection
    $email = $conn->real_escape_string($email);

    // Check credentials
    $sql = "SELECT * FROM registration WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 1) {
        $user = $result->fetch_assoc();

        // Verify password (no hashing in this case)
        if ($password === $user['password']) {
            // Set session variables
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];

            // Redirect based on email domain
            if (strpos($email, '@dentalclinic.com') !== false) {
                header("Location: doctor_dashboard.php"); // Redirect to doctor's dashboard
            } else {
                header("Location: index.php"); // Redirect to patient's dashboard (home page)
            }
            exit();
        } else {
            $login_error = true; // Incorrect password
        }
    } else {
        $login_error = true; // Email not found
    }
}

// Close the connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
</head>
<body>
    <main>
        <section class="login-form">
            <h1>Login to Dental Clinic</h1>
            <p>Enter your credentials to access your account.</p>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
                <?php if ($login_error): ?>
                    <p style="color: red;">Incorrect email or password. Please try again.</p>
                <?php endif; ?>
                <button type="submit" class="btn-submit">Login</button>
            </form>
            <p class="register-link">Don't have an account? <a href="registration.php">Register here</a>.</p>
        </section>
    </main>
</body>
</html>