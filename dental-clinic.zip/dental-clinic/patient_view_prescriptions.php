<?php include 'header.php'; ?>
<?php
$conn = new mysqli("localhost", "root", "", "kavs");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the logged-in patient's email
$patient_email = $_SESSION['user_email'];

// Fetch prescriptions for the logged-in patient
$stmt = $conn->prepare("SELECT p.prescription_text, p.created_at, d.name AS doctor_name 
                        FROM prescriptions p 
                        JOIN registration d ON p.doctor_id = d.id 
                        WHERE p.patient_email = ?");
$stmt->bind_param("s", $patient_email);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Prescriptions - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="view-prescriptions">
            <h1>Your Prescriptions</h1>
            <?php if ($result->num_rows > 0): ?>
                <table border="1">
                    <tr>
                        <th>Doctor</th>
                        <th>Prescription</th>
                        <th>Date</th>
                    </tr>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['doctor_name']); ?></td>
                            <td><?= htmlspecialchars($row['prescription_text']); ?></td>
                            <td><?= htmlspecialchars($row['created_at']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </table>
            <?php else: ?>
                <p>No prescriptions found.</p>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>