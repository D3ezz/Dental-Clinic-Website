<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Successful - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="confirmation">
            <h1>Registration Successful!</h1>
            <p>Thank you for registering at Dental Clinic. Your account has been created successfully.</p>
            <p>You can now <a href="login.php">log in</a> to access your account and book appointments.</p>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Dental Clinic. All rights reserved.</p>
    </footer>
</body>
</html>