<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
</head>

<br><br><br>

<body>
    <main>
        <section class="contact-page">
            <h1>Contact Us</h1>
            <p>If you have any questions or need assistance, feel free to reach out to us.</p>

            <div class="contact-details">
                <h2>Our Contact Information</h2>
                <p><strong>Phone:</strong> +971 4 123 4567</p>
                <p><strong>Email:</strong> info@dentalclinic.com</p>
                <p><strong>Address:</strong> 123 Dental Street, Downtown Dubai, Dubai, UAE</p>
            </div>

            <div class="map-container">
                <h2>Our Location</h2>
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3609.123456789012!2d55.27078231501034!3d25.20484998389998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f434567890123%3A0xabcdef1234567890!2sDowntown%20Dubai!5e0!3m2!1sen!2sae!4v1681234567890!5m2!1sen!2sae" 
                    width="100%" 
                    height="300" 
                    style="border:0;" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
        </section>
    </main>
</body>
</html>