<?php include 'header.php'; ?>
<?php


// Database connection settings
$host = "localhost";
$username = "root"; // change if different
$password = "";     // change if different
$database = "kavs";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $dob = $_POST["dob"];
    $gender = $_POST["gender"];
    $password = $_POST["password"];

    // Check if the email contains @dentalclinic.com
    if (strpos($email, '@dentalclinic.com') !== false) {
        $email_error = true; // Set an error flag for invalid email
    } else {
        // Escape input
        $name = $conn->real_escape_string($name);
        $email = $conn->real_escape_string($email);
        $phone = $conn->real_escape_string($phone);
        $dob = $conn->real_escape_string($dob);
        $gender = $conn->real_escape_string($gender);
        $password = $conn->real_escape_string($password); // Hash the password

        // Insert user into the registration table
        $stmt = $conn->prepare("INSERT INTO registration (name, email, phone, dob, gender, password) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $email, $phone, $dob, $gender, $password);

        if ($stmt->execute()) {
            header("Location: submit_registration.php"); // Redirect to a success page
            exit();
        } else {
            $registration_error = true; // Set an error flag for failed registration
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <style>
        .error {
            border: 2px solid red;
        }
    </style>
</head>
<body>
<br><br><br><br><br><br><br>
    <main>
        <section class="registration-form">
            <h1>Register at Dental Clinic</h1>
            <p>Fill out the form below to create your account and access our services.</p>
            <form action="" method="POST" onsubmit="return validatePasswords()">
                <div class="form-group">
                    <label for="full-name">Full Name</label>
                    <input type="text" id="full-name" name="name" placeholder="Enter your full name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" 
                        class="<?= isset($email_error) ? 'error' : '' ?>" required>
                    <?php if (isset($email_error)): ?>
                        <p style="color: red;">You cannot register with an email ending in @dentalclinic.com.</p>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required>
                </div>
                <div class="form-group">
                    <label for="dob">Date of Birth</label>
                    <input type="date" id="dob" name="dob" placeholder="Select your date of birth" required>
                </div>
                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select id="gender" name="gender" required>
                        <option value="" disabled selected>Select your gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    <ul id="password-requirements" class="hidden">
                        <li id="length" class="invalid">Minimum 8 characters</li>
                        <li id="uppercase" class="invalid">At least 1 uppercase letter</li>
                        <li id="symbol" class="invalid">At least 1 symbol</li>
                        <li id="numbers" class="invalid">At least 4 numbers</li>
                    </ul>
                </div>
                <div class="form-group">
                    <label for="confirm-password">Confirm Password</label>
                    <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm your password" required>
                </div>
                <?php if (isset($registration_error)): ?>
                    <p style="color: red;">Registration failed. Please try again.</p>
                <?php endif; ?>
                <button type="submit" class="btn-submit">Register</button>
            </form>
            <p class="login-link">Already have an account? <a href="login.php">Login here</a>.</p>
        </section>
    </main>
    <br><br><br>

    <script>
        function validatePasswords() {
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirm-password');
            const errorMessage = document.getElementById('password-error');

            if (password.value !== confirmPassword.value) {
                confirmPassword.classList.add('error'); // Add the error class
                errorMessage.style.display = 'block'; // Show the error message
                return false; // Prevent form submission
            } else {
                confirmPassword.classList.remove('error'); // Remove the error class
                errorMessage.style.display = 'none'; // Hide the error message
                return true; // Allow form submission
            }
        }

        // Set the max attribute of the Date of Birth field to today's date
        const dobInput = document.getElementById('dob');
        const today = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD format
        dobInput.setAttribute('max', today); // Set the max attribute to today's date
    </script>

    <script>
        const passwordInput = document.getElementById("password");
        const confirmPasswordInput = document.getElementById("confirm-password");
        const requirementsList = document.getElementById("password-requirements");
        const requirements = {
            length: document.getElementById("length"),
            uppercase: document.getElementById("uppercase"),
            symbol: document.getElementById("symbol"),
            numbers: document.getElementById("numbers"),
        };

        // Show the requirements list when the user starts typing
        passwordInput.addEventListener("focus", () => {
            requirementsList.classList.remove("hidden");
        });

        // Hide the requirements list when the input loses focus (if empty)
        passwordInput.addEventListener("blur", () => {
            if (passwordInput.value === "") {
                requirementsList.classList.add("hidden");
            }
        });

        // Validate password in real-time
        passwordInput.addEventListener("input", () => {
            const password = passwordInput.value;

            // Check for minimum 8 characters
            if (password.length >= 8) {
                requirements.length.classList.add("valid");
                requirements.length.classList.remove("invalid");
            } else {
                requirements.length.classList.add("invalid");
                requirements.length.classList.remove("valid");
            }

            // Check for at least 1 uppercase letter
            if (/[A-Z]/.test(password)) {
                requirements.uppercase.classList.add("valid");
                requirements.uppercase.classList.remove("invalid");
            } else {
                requirements.uppercase.classList.add("invalid");
                requirements.uppercase.classList.remove("valid");
            }

            // Check for at least 1 symbol
            if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
                requirements.symbol.classList.add("valid");
                requirements.symbol.classList.remove("invalid");
            } else {
                requirements.symbol.classList.add("invalid");
                requirements.symbol.classList.remove("valid");
            }

            // Check for at least 4 numbers
            if ((password.match(/\d/g) || []).length >= 4) {
                requirements.numbers.classList.add("valid");
                requirements.numbers.classList.remove("invalid");
            } else {
                requirements.numbers.classList.add("invalid");
                requirements.numbers.classList.remove("valid");
            }
        });

        // Prevent form submission if requirements are not met
        document.querySelector("form").addEventListener("submit", (e) => {
            const password = passwordInput.value;
            const confirmPassword = confirmPasswordInput.value;

            if (
                !(
                    password.length >= 8 &&
                    /[A-Z]/.test(password) &&
                    /[!@#$%^&*(),.?":{}|<>]/.test(password) &&
                    (password.match(/\d/g) || []).length >= 4
                )
            ) {
                e.preventDefault();
                alert("Please meet all password requirements.");
            }

            if (password !== confirmPassword) {
                e.preventDefault();
                alert("Passwords do not match.");
            }
        });
    </script>
</body>
</html>