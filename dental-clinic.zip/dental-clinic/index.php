<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dental Clinic - Home</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="welcome">
            <h1>Welcome to Our Dental Clinic</h1>
            <p>Your smile is our priority!</p>
            <div class="additional-content">
                <p>We provide world-class healthcare services tailored to your needs.</p>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Dental Clinic. All rights reserved.</p>
    </footer>
</body>
</html>