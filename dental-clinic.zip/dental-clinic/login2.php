<?php include 'header.php'; ?>

<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "kavs");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Escape input
    $email = $conn->real_escape_string($email);
    $password = $conn->real_escape_string($password);

    // Check credentials
    $sql = "SELECT * FROM registration WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        
        // Redirect based on email domain
        if (strpos($email, '@dentalclinic.com') !== false) {
            header("Location: doctor_dashboard.php"); // Redirect to doctor's dashboard
        } else {
            header("Location: index.php"); // Redirect to patient's dashboard
        }
        exit();
    } else {
      echo "<script>alert('Incorrect email or password.');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
</head>
<body>
    <main>
        <section class="login-form">
            <h1>Login to Dental Clinic</h1>
            <p>Enter your credentials to access your account.</p>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
                <button type="submit" class="btn-submit">Login</button>
            </form>
            <p class="register-link">Don't have an account? <a href="registration.php">Register here</a>.</p>
        </section>
    </main>
</body>
</html>