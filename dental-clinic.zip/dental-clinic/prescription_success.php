<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prescription Added - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="success-message">
            <h1>Prescription Successfully Added</h1>
            <?php if (isset($_GET['patient_name'])): ?>
                <p>The prescription has been successfully added for <strong><?= htmlspecialchars($_GET['patient_name']); ?></strong>.</p>
            <?php else: ?>
                <p>The prescription has been successfully added.</p>
            <?php endif; ?>
            <a href="doctor_dashboard.php" class="btn-back">Back to Dashboard</a>
        </section>
    </main>
</body>
</html>