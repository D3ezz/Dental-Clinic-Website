<?php
include 'header.php'; // Include the navigation bar

// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['user_name']) || !isset($_SESSION['user_email'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Database connection settings
$host = "localhost";
$username = "root"; // change if different
$password = "";     // change if different
$database = "kavs";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch specialties and doctors for dropdowns
$specialties = $conn->query("SELECT DISTINCT specialization FROM doctors");
$doctors = $conn->query("SELECT id, name, specialization FROM doctors");

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_name = $_SESSION['user_name'];
    $patient_email = $_SESSION['user_email'];
    $doctor_id = $_POST['doctor_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];

    $stmt = $conn->prepare("INSERT INTO appointments (patient_name, patient_email, doctor_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssiss", $patient_name, $patient_email, $doctor_id, $appointment_date, $appointment_time);

    if ($stmt->execute()) {
        // Redirect to the success page
        header("Location: appointment_success.php");
        exit();
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <br><br><br>
    <main>
        <section class="appointment-form">
            <h1>Book an Appointment</h1>
            <p>Fill out the form below to book an appointment with your selected doctor.</p>
            <form action="" method="POST" onsubmit="return validateForm()">
                <div class="form-group">
                    <label for="specialty">Select Specialty</label>
                    <select id="specialty" name="specialty" required>
                        <option value="" disabled selected>Select a specialty</option>
                        <?php while ($row = $specialties->fetch_assoc()): ?>
                            <option value="<?= $row['specialization'] ?>"><?= $row['specialization'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="doctor">Select Doctor</label>
                    <select id="doctor" name="doctor_id" required>
                        <option value="" disabled selected>Select a doctor</option>
                        <?php while ($row = $doctors->fetch_assoc()): ?>
                            <option value="<?= $row['id'] ?>" data-specialty="<?= $row['specialization'] ?>">
                                <?= $row['name'] ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="patient-name">Your Name</label>
                    <input type="text" id="patient-name" name="patient_name" placeholder="Enter your name" required>
                </div>
                <div class="form-group">
                    <label for="appointment-date">Appointment Date</label>
                    <input type="date" id="appointment-date" name="appointment_date" required>
                </div>
                <div class="form-group">
                    <label for="appointment-time">Appointment Time</label>
                    <input type="time" id="appointment-time" name="appointment_time" required>
                </div>
                <button type="submit" class="btn-submit">Book Appointment</button>
            </form>
        </section>
    </main>
    <script>
        // Set minimum date for the appointment date field
        document.addEventListener("DOMContentLoaded", function () {
            const today = new Date().toISOString().split("T")[0];
            document.getElementById("appointment-date").setAttribute("min", today);
        });

        // Validate the form before submission
        function validateForm() {
            const appointmentDate = document.getElementById("appointment-date").value;
            const appointmentTime = document.getElementById("appointment-time").value;

            const today = new Date();
            const selectedDate = new Date(appointmentDate);

            if (selectedDate.toDateString() === today.toDateString()) {
                const currentTime = today.getHours() + ":" + today.getMinutes();
                if (appointmentTime <= currentTime) {
                    alert("For today's appointments, the time must be later than the current time.");
                    return false;
                }
            }

            return true;
        }

        $(document).ready(function () {
            // Update doctor list based on selected specialty
            $('#specialty').on('change', function () {
                const selectedSpecialty = $(this).val();
                $('#doctor option').each(function () {
                    const doctorSpecialty = $(this).data('specialty');
                    if (doctorSpecialty === selectedSpecialty || !selectedSpecialty) {
                        $(this).show();
                    } else {
                        $(this).hide();
                    }
                });
                $('#doctor').val(''); // Reset doctor selection
            });

            // Update specialty based on selected doctor
            $('#doctor').on('change', function () {
                const selectedDoctorSpecialty = $('#doctor option:selected').data('specialty');
                $('#specialty').val(selectedDoctorSpecialty);
            });
        });
    </script>
</body>
</html>