<?php include 'header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book an Appointment - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <!-- Appointment Header -->
    <div class="appointment-header">
        <img src="assets/kavs.png" alt="Kavs Logo" class="appointment-logo">
        <h1>Book Your Appointment</h1>
    </div>

    <br><br><br><br><br><br><br><br><br>
    <div class="container">
        <div class="grid">
            <div class="wrapper">
                <h2>Dr. Hamdhan Mohamed</h2>
                <p>Specialization: Oral Surgeon</p>
                <p>Experience: 15 years</p>
                <p>Available: Mon-Fri, 9 AM - 3 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=1'">Book Appointment</button>
                </div>
            </div>
            <div class="wrapper">
                <h2>Dr. Ayman Ahmed</h2>
                <p>Specialization: Prosthodontist</p>
                <p>Experience: 6 years</p>
                <p>Available: Sat-Thu, 2 PM - 4 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=2'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Nabeel Jaldeen</h2>
                <p>Specialization: Orthodontist</p>
                <p>Experience: 10 years</p>
                <p>Available: Tue-Thu, 10 AM - 4 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=3'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Ahmed Faisal</h2>
                <p>Specialization: General Dentist</p>
                <p>Experience: 8 years</p>
                <p>Available: Mon-Fri, 10 AM - 5 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=4'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Aysha Akthar</h2>
                <p>Specialization: Periodontist</p>
                <p>Experience: 7 years</p>
                <p>Available: Sun-Thu, 10 AM - 12 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=5'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Umar Ayat</h2>
                <p>Specialization: Endodontist</p>
                <p>Experience: 6 years</p>
                <p>Available: Mon-Sat, 8 AM - 2 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=6'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Maryam Gul</h2>
                <p>Specialization: Prosthodontist</p>
                <p>Experience: 10 years</p>
                <p>Available: Mon-Fri, 8 AM - 3 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=7'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Muhammedh Mishal</h2>
                <p>Specialization: Orthodontist</p>
                <p>Experience: 12 years</p>
                <p>Available: Mon-Fri, 10 AM - 5 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=8'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Irfana Jaleel</h2>
                <p>Specialization: Pedodontist</p>
                <p>Experience: 2 years</p>
                <p>Available: Mon-Wed, 7 AM - 6 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=9'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Muhammad Mural</h2>
                <p>Specialization: Cosmetic Dentist</p>
                <p>Experience: 11 years</p>
                <p>Available: Mon-Fri, 10 AM - 5 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=10'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Safa Khan</h2>
                <p>Specialization: Oral Pathologist</p>
                <p>Experience: 5 years</p>
                <p>Available: Thu-Tue, 10 AM - 3 PM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=11'">Book Appointment</button>
                </div>
            </div>

            <div class="wrapper">
                <h2>Dr. Sayed Bob</h2>
                <p>Specialization: Dental Radiologist</p>
                <p>Experience: 3 years</p>
                <p>Available: Mon-Thu, 6 PM - 2 AM</p>
                <div class="btn">
                    <button onclick="window.location.href='book_appointment.php?doctor_id=12'">Book Appointment</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>