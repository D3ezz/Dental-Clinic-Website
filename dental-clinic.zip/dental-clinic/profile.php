<?php include 'header.php'; ?>
<?php
$conn = new mysqli("localhost", "root", "", "kavs");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the logged-in patient's email
$patient_email = $_SESSION['user_email'];

// Fetch the next appointment for the logged-in patient
$stmt = $conn->prepare("SELECT a.appointment_date, a.appointment_time, d.name AS doctor_name 
                        FROM appointments a 
                        JOIN doctors d ON a.doctor_id = d.id 
                        WHERE a.patient_email = ? 
                        AND CONCAT(a.appointment_date, ' ', a.appointment_time) > NOW() 
                        ORDER BY a.appointment_date, a.appointment_time 
                        LIMIT 1");
$stmt->bind_param("s", $patient_email);
$stmt->execute();
$result = $stmt->get_result();
$next_appointment = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Dental Clinic</title>
    <link rel="stylesheet" href="assets/styles/style.css">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>
    <main>
        <section class="profile">
            <h1>Welcome, <?= htmlspecialchars($_SESSION['user_name']); ?></h1>
            <p>Your profile details and upcoming appointments are listed below.</p>

            <?php if ($next_appointment): ?>
                <div class="next-appointment">
                    <h2>Next Appointment</h2>
                    <p><strong>Doctor:</strong> <?= htmlspecialchars($next_appointment['doctor_name']); ?></p>
                    <p><strong>Date:</strong> <?= htmlspecialchars($next_appointment['appointment_date']); ?></p>
                    <p><strong>Time:</strong> <?= htmlspecialchars($next_appointment['appointment_time']); ?></p>
                    <p id="countdown"></p>
                </div>
            <?php else: ?>
                <p>You have no upcoming appointments.</p>
            <?php endif; ?>
            <a href="logout.php" class="btn-logout">Logout</a>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Dental Clinic. All rights reserved.</p>
    </footer>

    <?php if ($next_appointment): ?>
        <script>
            // Countdown Timer
            const appointmentDate = "<?= $next_appointment['appointment_date']; ?>";
            const appointmentTime = "<?= $next_appointment['appointment_time']; ?>";
            const appointmentDateTime = new Date(`${appointmentDate}T${appointmentTime}`);

            function updateCountdown() {
                const now = new Date();
                const timeDifference = appointmentDateTime - now;

                if (timeDifference <= 0) {
                    document.getElementById("countdown").innerText = "Your appointment is now!";
                    clearInterval(countdownInterval);
                    return;
                }

                const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
                const hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((timeDifference % (1000 * 60)) / 1000);

                document.getElementById("countdown").innerText = 
                    `Time until appointment: ${days}d ${hours}h ${minutes}m ${seconds}s`;
            }

            const countdownInterval = setInterval(updateCountdown, 1000);
            updateCountdown(); // Initial call to display immediately
        </script>
    <?php endif; ?>

    <?php if (isset($_SESSION['user_email']) && strpos($_SESSION['user_email'], '@dentalclinic.com') !== false): ?>
        <!-- Doctor's Navigation -->
        <li><a href="doctor_dashboard.php" class="<?= $current_page == 'doctor_dashboard.php' ? 'active' : '' ?>">Home</a></li>
        <li><a href="doctor_appointments.php" class="<?= $current_page == 'doctor_appointments.php' ? 'active' : '' ?>">Appointments</a></li>
        <li><a href="doctor_patients.php" class="<?= $current_page == 'doctor_patients.php' ? 'active' : '' ?>">Patients</a></li>
        <li><a href="doctor_next_patient.php" class="<?= $current_page == 'doctor_next_patient.php' ? 'active' : '' ?>">Next Patient</a></li>
    <?php endif; ?>
</body>
</html>